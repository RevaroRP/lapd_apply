const container = document.getElementById('container');
const form = document.getElementById('applyForm');
const cancelBtn = document.getElementById('cancelBtn');
const msg = document.getElementById('msg');

// Zeige nur bei "open", ansonsten bleibt es unsichtbar
window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.action === 'open') {
    container.classList.add('show');   // -> display:flex
  } else if (data.action === 'close') {
    container.classList.remove('show'); // -> display:none
  }
});

// ESC = schließen
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: '{}' });
  }
});
cancelBtn.addEventListener('click', () => {
  fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: '{}' });
});

// Submit
form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  msg.textContent = "";

  const data = {
    firstname: form.firstname.value.trim(),
    lastname:  form.lastname.value.trim(),
    age:       form.age.value.trim(),
    gender:    form.gender.value,
    motivation:form.motivation.value.trim()
  };

  const res = await fetch(`https://${GetParentResourceName()}/submitForm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data)
  });

  await res.json().catch(() => ({}));
  msg.textContent = "Bewerbung gesendet!";
  setTimeout(() => {
    fetch(`https://${GetParentResourceName()}/close`, { method: 'POST', body: '{}' });
  }, 500);
});
