local applyPoint = vec3(443.6446, -981.0452, 30.6893, 94.0600)
local heading    = 274.3826
local openRadius = 2.0
local nuiOpen    = false
local keyE       = 38 -- E

-- NUI beim Start garantiert zu + kein Fokus
CreateThread(function()
    Wait(250)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end)

-- kleiner 3D-Hinweis
local function Draw3DText(x, y, z, text)
    SetDrawOrigin(x, y, z, 0)
    SetTextFont(4); SetTextScale(0.32, 0.32)
    SetTextColour(255,255,255,215); SetTextCentre(true)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

-- Nähe checken und E öffnen
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local dist = #(GetEntityCoords(ped) - applyPoint)

        if dist <= 25.0 then
            sleep = 0
            DrawMarker(2, applyPoint.x, applyPoint.y, applyPoint.z + 0.1,
                       0.0,0.0,0.0, 0.0,0.0,heading,
                       0.35,0.35,0.35, 45,140,255,180, false,true,2,false,nil,nil,false)
        end

        if dist <= openRadius and not nuiOpen then
            Draw3DText(applyPoint.x, applyPoint.y, applyPoint.z + 0.55, "~g~~h~[E]~s~ Bewerben (LSPD)")
            if IsControlJustPressed(0, keyE) then
                nuiOpen = true
                SetNuiFocus(true, true)
                SendNUIMessage({ action = "open" })
            end
        end

        Wait(sleep)
    end
end)

-- ESC/Abbrechen -> schließen
RegisterNUICallback("close", function(_, cb)
    nuiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
    cb("ok")
end)

-- Formular absenden
RegisterNUICallback("submitForm", function(data, cb)
    TriggerServerEvent("lspd_apply:submit", data)
    nuiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
    cb({ ok = true })
end)

-- Fallback vom Server
RegisterNetEvent("lspd_apply:forceClose", function()
    if nuiOpen then
        nuiOpen = false
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "close" })
    end
end)
