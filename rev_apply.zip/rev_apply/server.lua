-- >>>>> DISCORD KONFIG <<<<<
-- Standardmäßig dein bekannter Webhook (bitte bei Bedarf ersetzen)
local DISCORD_WEBHOOK = ""

-- Optional: Roll-Mentions (ersetzen durch echte IDs oder leer lassen)
local ROLE_CHIEF_ID = "1381326640491008182"  -- z.B. "123456789012345678"
local ROLE_ADMIN_ID = "1381326580122521723"  -- z.B. "234567890123456789"

-- Nachrichten-Format
local function sendToDiscord(name, data, src)
    local playerName = GetPlayerName(src) or "Unbekannt"
    local mention = ""
    if ROLE_CHIEF_ID ~= "" then mention = mention .. "<@&" .. ROLE_CHIEF_ID .. "> " end
    if ROLE_ADMIN_ID ~= "" then mention = mention .. "<@&" .. ROLE_ADMIN_ID .. "> " end

    local embed = {
        {
            title = "Neue LSPD Bewerbung",
            description = string.format("**Von:** %s\n%s", playerName, mention),
            color = 5793266, -- blau-ish
            fields = {
                { name = "Vorname", value = data.firstname, inline = true },
                { name = "Nachname", value = data.lastname, inline = true },
                { name = "Alter", value = tostring(data.age), inline = true },
                { name = "Geschlecht", value = data.gender, inline = true },
                { name = "Motivation", value = data.motivation, inline = false },
            },
            footer = { text = os.date("Gesendet am %d.%m.%Y um %H:%M:%S") }
        }
    }

    PerformHttpRequest(DISCORD_WEBHOOK, function() end, 'POST',
        json.encode({
            username = "LSPD Bewerbungen",
            avatar_url = "https://i.imgur.com/ixH3h1x.png",
            content = mention ~= "" and mention or nil,
            embeds = embed
        }),
        { ['Content-Type'] = 'application/json' }
    )
end

-- einfache Server-Validierung + Rate-Limit
local lastSubmit = {}

RegisterNetEvent("lspd_apply:submit", function(data)
    local src = source
    local now = os.time()
    if lastSubmit[src] and (now - lastSubmit[src]) < 10 then
        return -- spam block
    end
    lastSubmit[src] = now

    local ok = true
    local age = tonumber(data.age or 0) or 0
    local function sane(s) return type(s)=="string" and #s >= 2 and #s <= 64 end

    if not sane(data.firstname) or not sane(data.lastname) then ok = false end
    if age < 16 or age > 80 then ok = false end
    if not sane(data.gender) then ok = false end
    if type(data.motivation) ~= "string" or #data.motivation < 10 or #data.motivation > 1000 then ok = false end

    if not ok then
        TriggerClientEvent("chat:addMessage", src, { args = {"LSPD", "^1Ungültige Eingaben. Bitte prüfe deine Daten."}})
        TriggerClientEvent("lspd_apply:forceClose", src)
        return
    end

    sendToDiscord("LSPD Bewerbung", data, src)
    TriggerClientEvent("chat:addMessage", src, { args = {"LSPD", "^2Deine Bewerbung wurde gesendet. Vielen Dank!"}})
    TriggerClientEvent("lspd_apply:forceClose", src)
end)
