fx_version 'cerulean'
game 'gta5'

name 'lspd_apply'
author 'Robert'
description 'LSPD Bewerbungsformular mit NUI und Discord Webhook'
version '1.0.0'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/app.js'
}

client_scripts { 'client.lua' }
server_scripts { 'server.lua' }
